package com.example.test04system2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Test04System2ApplicationTests {

	@Test
	void contextLoads() {
	}

}

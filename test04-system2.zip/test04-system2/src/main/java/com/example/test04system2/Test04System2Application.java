package com.example.test04system2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Test04System2Application {

	public static void main(String[] args) {
		SpringApplication.run(Test04System2Application.class, args);
	}

}
